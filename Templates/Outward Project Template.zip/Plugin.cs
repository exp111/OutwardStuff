﻿using BepInEx;
using BepInEx.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace $projectname$
{
    [BepInPlugin(ID, NAME, VERSION)]
    public class $projectname$ : BaseUnityPlugin
    {
        public const string ID = "com.exp111.$projectname$";
        public const string NAME = "$projectname$";
        public const string VERSION = "1.0";

        public static ManualLogSource Log;

        public void Awake()
        {
            try
            {
                Log = Logger;
                Log.LogMessage("Awake");
                DebugLog("Using a DEBUG build.");
            }
            catch (Exception e)
            {
                Log.LogMessage($"Exception during $projectname$.Awake: {e}");
            }
        }

        public void OnDestroy()
        {
            // Delete your stuff
        }

        [Conditional("DEBUG")]
        public static void DebugLog(string message)
        {
            Log.LogMessage(message);
        }

        [Conditional("TRACE")]
        public static void DebugTrace(string message)
        {
            Log.LogMessage(message);
        }
    }
}
