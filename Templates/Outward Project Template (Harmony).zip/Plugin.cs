﻿using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using System;
using System.Diagnostics;
using System.Reflection;

namespace $safeprojectname$
{
    [BepInPlugin(ID, NAME, VERSION)]
    public class $safeprojectname$ : BaseUnityPlugin
    {
        public const string ID = "com.exp111.$safeprojectname$";
        public const string NAME = "$safeprojectname$";
        public const string VERSION = "1.0";

        public static ManualLogSource Log;
        private static Harmony Harmony;

        public void Awake()
        {
            try
            {
                Log = Logger;
                Log.LogMessage("Awake");
                DebugLog("Using a DEBUG build.");

                // Init Harmony
                Harmony = Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly(), ID);
            }
            catch (Exception e)
            {
                Log.LogMessage($"Exception during $safeprojectname$.Awake: {e}");
            }
        }

        public void OnDestroy()
        {
            // Delete your stuff
            Harmony?.UnpatchSelf();
        }

        [Conditional("DEBUG")]
        public static void DebugLog(string message)
        {
            Log.LogMessage(message);
        }

        [Conditional("TRACE")]
        public static void DebugTrace(string message)
        {
            Log.LogMessage(message);
        }
    }
}
